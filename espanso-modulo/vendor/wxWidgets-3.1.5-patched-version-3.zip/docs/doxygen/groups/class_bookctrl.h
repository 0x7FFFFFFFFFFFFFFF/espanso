/////////////////////////////////////////////////////////////////////////////
// Name:        class_bookctrl.h
// Purpose:     Book controls classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_bookctrl Book Controls
@ingroup group_class

A book control contains pages of other controls.

Related overview: @ref overview_bookctrl

*/

